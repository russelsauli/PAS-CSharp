﻿using PAS.InputValidator;
using PAS.NumberGenerator;
using POCO.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PAS.Claim
{
    public class ClaimData
    {
        public Claims ClaimDatas(Policies policy) {

            ValidateInput validateInput = new ValidateInput();
            GenerateNumber generateNumber = new GenerateNumber();
            DateTime dateTime = DateTime.Now;
            PASContext pasContext = new PASContext();

            List<Claims> claimsList = pasContext.Claims.ToList();
            Claims claims = new Claims();

            claims.PolicyId = policy.PolicyId;

            do
            {
                claims.ClaimNumber = generateNumber.GenerateRandom(5, 99999, "C");
            }
            while (claimsList.Exists(x => x.ClaimNumber.Equals(claims.ClaimNumber)));

            do {

                claims.AccidentDate = validateInput.ValidateDate("Accident Date      :");

                if (claims.AccidentDate > dateTime) {
                    Console.WriteLine("Cant accept future date");
                }
                else if (claims.AccidentDate < policy.EffectiveDate) {
                    Console.WriteLine("The policy is not yet active the date of the accident");
                }

            } while (claims.AccidentDate> dateTime || claims.AccidentDate < policy.EffectiveDate);

            claims.AccidentLocation = validateInput.ValidateString("Accident Location  : ");
            claims.AccidentDescription = validateInput.ValidateString("Accident Descrption: ");
            claims.DescriptionOfDamage = validateInput.ValidateString("Damage  Description: ");
            claims.EstimateCost = validateInput.ValidateDecimal("Estimate Cost      : ");

            return claims;
        }

    }
}
