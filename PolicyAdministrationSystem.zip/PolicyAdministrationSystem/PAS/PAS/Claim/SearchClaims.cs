﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Identity.Client;
using PAS.InputValidator;
using PAS.Print;
using POCO.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;

namespace PAS.Claim
{
    public class SearchClaims
    {
        public void SearchClaim() {

            PASContext pasContext= new PASContext();
            ValidateInput validateInput = new ValidateInput();
            Printing printing = new Printing(); 

            List<Claims> claimList= pasContext.Claims.Include(x=>x.Policy).Include(x => x.Policy.PolicyHolder).Include(x => x.Policy.PolicyHolder.CustomerAccount).ToList();

            Claims claim = new Claims();

            string claimNumber = "";

            Console.WriteLine("SEARCH FOR A CUSTOMER ACCOUNT ");

            claimNumber = validateInput.ValidateString("Enter Claim number: ");

            if (claimList.Exists(x=>x.ClaimNumber.Equals(claimNumber)))
            {
                claim= claimList.Where((x => x.ClaimNumber.Equals(claimNumber))).First();

                printing.PrintData(claim);

                printing.PrintData(claim.Policy);

                printing.PrintData(claim.Policy.PolicyHolder);

                printing.PrintData(claim.Policy.PolicyHolder.CustomerAccount);
            }
            else {

                Console.WriteLine("Claim number not exist");
            }

        }
    }
}
