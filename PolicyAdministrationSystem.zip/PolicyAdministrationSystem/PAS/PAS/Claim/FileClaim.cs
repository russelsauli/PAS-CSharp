﻿using PAS.InputValidator;
using PAS.Print;
using POCO.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;

namespace PAS.Claim
{
    public class FileClaim
    {
        public void FileClaims() {

            PASContext db = new PASContext();
            Printing print = new Printing();
            ValidateInput validateInput = new ValidateInput();
            ClaimData claimData = new ClaimData();

            DateTime dateTime = DateTime.Now;
         
            Policies policies = new Policies();
            Claims claims = new Claims();
            List<Policies> policyList = db.Policies.ToList();

            string policyNumber = "",selectOption="";

            Console.WriteLine("FILE AN ACCIDENT CLAIM AGAINST A POLICY.");

            policyNumber = validateInput.ValidateString("Input policy number: ");

            if ((policyList.Exists(x => x.PolicyNumber.Equals(policyNumber) && x.IsExpired ==true))) {
                Console.WriteLine("Cant file a claim policy already expired");
            }

            else if ((policyList.Exists(x => x.PolicyNumber.Equals(policyNumber) && x.EffectiveDate > dateTime))) {

                Console.WriteLine("Policy is not yet active as the time of filing");
            }
            else if (policyList.Exists(x => x.PolicyNumber.Equals(policyNumber)))
            {
                policies = policyList.Where(x => x.PolicyNumber.Equals(policyNumber)).First();
                claims = claimData.ClaimDatas(policies);

                print.PrintData(claims);
                selectOption =validateInput.ValidateYESNO("Do you want to file this claim? Y/N: ");

                if (selectOption.Equals("Y")) {
                    
                    db.Claims.Add(claims);
                    db.SaveChanges();

                    Console.WriteLine("A claim had beed filed");
                }
            }
            else
            {
                Console.WriteLine("Policy Number doesn't exist");
            }
        }
    }
}
