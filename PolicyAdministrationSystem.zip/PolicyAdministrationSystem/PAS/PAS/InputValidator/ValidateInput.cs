﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PAS.InputValidator
{
    public class ValidateInput
    {
        public DateTime ValidateDate(string info)
        {
            DateTime dateTime = DateTime.Now;
            int month=0, day = 0, year = 0;
            bool isValidFormat = false;

            do
            {
                try
                {
                    Console.Write(info);

                    Console.Write("\nInput Month: ");
                    month = int.Parse(Console.ReadLine());

                    Console.Write("\nInput Day: ");
                    day = int.Parse(Console.ReadLine());

                    Console.Write("\nInput Year: ");
                    year = int.Parse(Console.ReadLine());

                    dateTime = DateTime.Parse(day + "-" + month + "-" + year);

                    isValidFormat = true;
                }

                catch (Exception e)
                {

                    Console.WriteLine("Invalid Input");
                }

            } while (isValidFormat == false);

            return dateTime;
        }

        public int ValidateInt(string info)
        {

            int input = 0;

            do
            {

                try
                {
                    Console.Write(info);
                    input = int.Parse(Console.ReadLine());

                }
                catch (Exception e)
                {
                    Console.WriteLine("Invalid Input");
                    input = 0;
                }

            } while (input == 0);

            return input;

        }

        public decimal ValidateDecimal(string info)
        {
            decimal input = 0;

            do
            {
                try
                {
                    Console.Write(info);
                    input = decimal.Parse(Console.ReadLine());

                }
                catch (Exception e)
                {
                    Console.WriteLine("Invalid Input");
                    input = 0;
                }

            } while (input == 0);

            return Math.Round(input, 2);
        }

        public string ValidateString(string info)
        {
            string input = null;

            do
            {
                Console.Write(info);
                input = Console.ReadLine();

                if (input.Equals(""))
                {
                    Console.WriteLine("Input cant be null");
                    input = "";
                }
                else if (input.Equals(null))
                {
                    Console.WriteLine("Input cant be null");
                    input = "";
                }

            } while (input == "");

            return input.ToUpper();
        }

        public string ValidateYESNO(string info)
        {
            string input = "";
            bool isValidInput = false;
            do
            {
                input = ValidateString(info);

                if (input.Equals("Y") || input.Equals("N"))
                {
                    isValidInput = true;
                }
                else
                {
                    Console.WriteLine("Invalid Input");
                }

            } while (isValidInput == false);

            return input;
        }
    }
}
