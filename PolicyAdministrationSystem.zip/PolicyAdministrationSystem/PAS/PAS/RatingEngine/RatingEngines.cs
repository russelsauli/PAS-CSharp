﻿using POCO.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PAS.RatingEngine
{
    public class RatingEngines
    {
        public decimal PremiumCharge(Vehicles vehicles, PolicyHolders policyHolders)
        {
            DateTime dateTime = DateTime.Now;

            double vpf = 0;

            int dlx;

            dlx = policyHolders.DriversLicenseIssued.Year; // substirng or getting  only the year of the license issued date using substring method and index of 

            dlx = dateTime.Year - dlx;    // substrution of current year and the result of dlx

            // if dlx is less than 0 set to 1
            if (dlx <= 0)
            {
                dlx = 1;
            }

            int vehicleAge = dateTime.Year - vehicles.Year;   //subtrang the curent year and the year

            if (vehicleAge <= 1)
            {
                vpf = 0.01;
            }
            else if (vehicleAge <= 3)
            {
                vpf = 0.008;
            }
            else if (vehicleAge <= 5)
            {
                vpf = 0.007;
            }
            else if (vehicleAge <= 10)
            {
                vpf = 0.006;
            }
            else if (vehicleAge <= 15)
            {
                vpf = 0.004;
            }
            else if (vehicleAge <= 20)
            {
                vpf = 0.002;
            }

            else if (vehicleAge <= 40)
            {
                vpf = 0.001;
            }

            else if (vehicleAge >= 40)
            {
                vpf = 0.001;
            }

            vehicles.PremiumCharged = (vehicles.PurchasePrice * (decimal)vpf) + ((vehicles.PurchasePrice / 100) / dlx); // set premiumcharge;

            vehicles.PremiumCharged = Math.Round(vehicles.PremiumCharged, 2); // set premiumcharge 2 deciamal point;

            return vehicles.PremiumCharged;
        }
    }
}
