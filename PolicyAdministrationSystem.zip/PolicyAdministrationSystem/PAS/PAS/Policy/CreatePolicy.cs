﻿using PAS.InputValidator;
using PAS.PolHolder;
using PAS.Print;
using PAS.Vehicle;
using POCO.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PAS.Policy
{
    public class CreatePolicy
    {
        public void CreatePolicies() {

            PASContext pasContext = new PASContext();  
            
            Printing printing = new Printing();

            ValidateInput validateInput = new ValidateInput();

            AddPolicyHolder addPolicyHolder = new AddPolicyHolder();

            AddVehicle addVehicle = new AddVehicle();

            PolicyDetails policyDetails = new PolicyDetails();

            CustomerAccounts customerAccounts = new CustomerAccounts();

            PolicyHolders policyHolders = new PolicyHolders();

            Policies policies = new Policies();

            Vehicles vehicles = new Vehicles();

            List<CustomerAccounts> customerList= pasContext.CustomerAccounts.ToList();

            List<PolicyHolders> policyHolderList = pasContext.PolicyHolders.ToList();

            List<Vehicles> vehicleList = new List<Vehicles>();

            string accountNumber = "",optionChoice;
            decimal totalPremium = 0;

            Console.WriteLine("GET A POLICY QUOTE AND BUY THE POLICY.\n");

            accountNumber = validateInput.ValidateString("Enter Customer Account Number");

            if (customerList.Exists(x => x.AccountNumber.Equals(accountNumber)))
            {
                customerAccounts= customerList.Where(x => x.AccountNumber.Equals(accountNumber)).First();
                policies = policyDetails.PolicyDetail(policies);

                do
                {
                    policyHolders= addPolicyHolder.AddPolicyHolders(customerAccounts);
                    printing.PrintData(policyHolders);
                    optionChoice = validateInput.ValidateYESNO("Do you want to used this policy holder details? Y/N: ");

                } while (!optionChoice.Equals("Y"));

                do
                {
                    vehicleList = addVehicle.AddVehicles(vehicleList, policyHolders);

                    optionChoice = validateInput.ValidateYESNO("Do you want to add another car in this policy? Y/N: ");

                } while (optionChoice.Equals("Y"));

                printing.PrintData(policyHolders);

                foreach (Vehicles data in vehicleList)
                {
                    totalPremium += data.PremiumCharged;
                    printing.PrintData(data);
                }
                policies.PremiumCharge = totalPremium;

                printing.PrintData(policies);

                optionChoice = validateInput.ValidateYESNO("Do you want to save this policy? Y/N: ");

                if (optionChoice.Equals("Y"))
                {
                    if (policyHolders.PolicyHolderId == 0)
                    {

                        pasContext.PolicyHolders.Add(policyHolders);
                        pasContext.SaveChanges();
                    }

                    policies.PolicyHolderId = policyHolders.PolicyHolderId;
                    pasContext.Policies.Add(policies);
                    pasContext.SaveChanges();

                    foreach (Vehicles data in vehicleList)
                    {
                        data.PolicyId = policies.PolicyId;
                        pasContext.Vehicles.Add(data);
                        pasContext.SaveChanges();
                    }

                    Console.WriteLine("New Policy had been created");
                }
                else {
                    Console.WriteLine("Policy not Created");
                }
            }
            else {
                Console.WriteLine("Account number not exist");
            }
        }
    }
}
