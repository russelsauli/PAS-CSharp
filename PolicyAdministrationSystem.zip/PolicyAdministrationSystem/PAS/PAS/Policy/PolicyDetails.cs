﻿using PAS.InputValidator;
using PAS.NumberGenerator;
using POCO.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PAS.Policy
{
    public class PolicyDetails
    {
        public Policies PolicyDetail(Policies policies) {
           
            PASContext db = new PASContext();

            ValidateInput ValidateInput = new ValidateInput();

            GenerateNumber generateNumber = new GenerateNumber();   
            
            List<Policies> policiesList = db.Policies.ToList();

            do
            {
                policies.EffectiveDate = ValidateInput.ValidateDate("Enter Policy Effective date");

                if (policies.EffectiveDate < DateTime.Now)
                {
                    Console.WriteLine("Can accept date that is later than today date");
                }

            } while (policies.EffectiveDate < DateTime.Now);

            policies.ExpirationDate = policies.EffectiveDate.AddMonths(6);
            policies.IsClaimed = false;
            policies.IsExpired = false;

            do
            {
                policies.PolicyNumber = generateNumber.GenerateRandom(6, 999999, "");

            } while (policiesList.Exists(x => x.PolicyNumber.Equals(policies.PolicyNumber)));

            return policies;

        }
    }
}
