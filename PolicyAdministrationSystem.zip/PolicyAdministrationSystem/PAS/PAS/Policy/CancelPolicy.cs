﻿using Microsoft.EntityFrameworkCore;
using PAS.InputValidator;
using PAS.Print;
using POCO.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PAS.Policy
{
    public class CancelPolicy
    {
        public void CancelPolicies() {

            PASContext pasContext = new PASContext();
            ValidateInput validateInput = new ValidateInput();
            Printing printing = new Printing(); 
            
            Policies policies = new Policies(); 
            List<Policies> policyList= pasContext.Policies.Include(x=>x.PolicyHolder).Include(x=>x.PolicyHolder.CustomerAccount).ToList();

            string policyNumber = "",choiceOption="";
            Console.WriteLine("CANCEL A SPECIFIC POLICY");

            policyNumber=validateInput.ValidateString("\nEnter policy number : ");

            if (policyList.Exists(x=>x.PolicyNumber.Equals(policyNumber))) {

                policies= policyList.Where(x => x.PolicyNumber.Equals(policyNumber)).First();

               
                printing.PrintData(policies);
                printing.PrintData(policies.PolicyHolder.CustomerAccount);
                printing.PrintData(policies.PolicyHolder);

                choiceOption=validateInput.ValidateYESNO("Do you want to cancel this policy: ");
                if (choiceOption.Equals("Y"))
                {
                    policies.IsExpired = true;
                    pasContext.Policies.Update(policies);
                    pasContext.SaveChanges();

                    Console.WriteLine("Policy had been canceled");
                }
                else {
                    Console.WriteLine("Policy not continue to cancel");
                }
            }
            else {

                Console.WriteLine("Policy number not exist");
            }

        }
    }
}
