﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PAS.NumberGenerator
{
    public class GenerateNumber
    {
        public string GenerateRandom(int sizeFormat, int maxRandomNumber, String format)
        {

            Random random = new Random();   // instiantiate random

            string generateNumber = "";

            int randomAccountNumber = 0; // the result of random number

            randomAccountNumber = random.Next(1, maxRandomNumber + 1); // random a number resulting

            generateNumber = randomAccountNumber.ToString();

            while (generateNumber.Length < sizeFormat)
            {   // while the length of teh generate number not match add 0 infront of it

                generateNumber = "0" + generateNumber;
            }

            generateNumber = format + generateNumber;   // add the format of number

            return generateNumber;
        }
    }
}
