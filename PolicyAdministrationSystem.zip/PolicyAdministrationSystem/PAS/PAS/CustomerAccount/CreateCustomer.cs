﻿using PAS.InputValidator;
using PAS.NumberGenerator;
using PAS.Print;
using POCO.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PAS.CustomerAccount
{
    public class CreateCustomer
    {
        public void CreateCustomers() {
        
            PASContext pasContext= new PASContext();

            ValidateInput validateInput = new ValidateInput();

            GenerateNumber generateNumber = new GenerateNumber();

            Printing printing = new Printing();

            List<CustomerAccounts> customerAccountsList = pasContext.CustomerAccounts.ToList(); 

            CustomerAccounts customer = new CustomerAccounts();

            Console.WriteLine("CREATE A NEW CUSTOMER ACCOUNT");

            customer.FirstName = validateInput.ValidateString("\nEnter first name :").ToUpper();

            customer.LastName = validateInput.ValidateString("\nEnter last name :").ToUpper();

            if (customerAccountsList.Exists(x => x.FirstName.Equals(customer.FirstName) && x.LastName.Equals(customer.LastName)))
            {
                Console.WriteLine("\nCustomer already had a account");
            }
            else {
              
                customer.Address = validateInput.ValidateString("\nAddress :").ToUpper();

                do
                {
                    customer.AccountNumber = generateNumber.GenerateRandom(4, 9999, "");

                } while (customerAccountsList.Exists(x => x.AccountNumber.Equals(customer.AccountNumber)));

                pasContext.CustomerAccounts.Add(customer);
                pasContext.SaveChanges();

                Console.WriteLine("\nNew Customer Account had been created");
                printing.PrintData(customer);
            }
        }
    }
}
