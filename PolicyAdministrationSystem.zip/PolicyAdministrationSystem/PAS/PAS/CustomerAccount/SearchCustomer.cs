﻿using Microsoft.EntityFrameworkCore;
using PAS.InputValidator;
using PAS.NumberGenerator;
using PAS.Print;
using POCO.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PAS.CustomerAccount
{
    public class SearchCustomer
    {
        public void SearchCustomerAccount() {

            PASContext _pasContext = new PASContext();
            ValidateInput validateInput = new ValidateInput();
            Printing printing = new Printing();

            Console.WriteLine("Search Customer Account");

            List<Policies> policyList= new List<Policies>();
            List<PolicyHolders> policyHolderList = new List<PolicyHolders>();

            List<CustomerAccounts> customerAccountList = _pasContext.CustomerAccounts.ToList();
            CustomerAccounts customer= new CustomerAccounts();

            string customerAccountNumber = "";

      
            customerAccountNumber = validateInput.ValidateString("Enter Customer Account Number");


            if (customerAccountList.Exists(x=>x.AccountNumber.Equals(customerAccountNumber))){

                customer = customerAccountList.Where(x => x.AccountNumber.Equals(customerAccountNumber)).First();

                printing.PrintData(customer);

                policyHolderList=_pasContext.PolicyHolders.Include(x=>x.CustomerAccount).ToList();

                policyList = _pasContext.Policies.Include(x => x.PolicyHolder).Include(x=>x.PolicyHolder.CustomerAccount).ToList();

                foreach (PolicyHolders data in policyHolderList.Where(x=>x.CustomerAccount.Equals(customer))) {

                    printing.PrintData(data);
                }

                foreach (Policies data in policyList.Where(x => x.PolicyHolder.CustomerAccount.Equals(customer)))
                {
                    printing.PrintData(data);
                }

            }

            else {

                Console.WriteLine("Customer Account Number Not Exist");
            }

        }
    }
}
