﻿using Microsoft.EntityFrameworkCore;
using PAS.InputValidator;
using PAS.Print;
using PAS.RatingEngine;
using POCO.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PAS.Vehicle
{
    public class AddVehicle
    {
        public List<Vehicles> AddVehicles(List<Vehicles> currentVehicleList,PolicyHolders policyHolders) {

            PASContext _pasContext = new PASContext();

            ValidateInput validateInput = new ValidateInput();

            Printing printing = new Printing();

            RatingEngines ratingEngines = new RatingEngines();  

            Vehicles vehicles = new Vehicles();

            DateTime dateTime = DateTime.Now;

            Console.WriteLine("Add Vehicle");

            List<Vehicles> vehicleList = _pasContext.Vehicles.Include(x => x.Policy).ToList();
           
            int selectionOption=0;

            do {
               
                vehicles.PlateNumber = validateInput.ValidateString("\nEnter Plate Number");

                if (vehicleList.Exists(x => x.Policy.IsExpired == false && x.PlateNumber.Equals(vehicles.PlateNumber))) {

                    Console.WriteLine("Vehicle already had a active policy");
                }
                else if (currentVehicleList.Exists(x => x.PlateNumber.Equals(vehicles.PlateNumber))){
                    Console.WriteLine("Vehicle already added");
                }

            } while (vehicleList.Exists(x=>x.Policy.IsExpired==false && x.PlateNumber.Equals(vehicles.PlateNumber)) || currentVehicleList.Exists(x => x.PlateNumber.Equals(vehicles.PlateNumber)));

            vehicles.Maker = validateInput.ValidateString("\nEnter Maker :");
            vehicles.Model = validateInput.ValidateString("\nEnter Model :");
            vehicles.Color = validateInput.ValidateString("\nEnter Color :");

            do
            {
                vehicles.Year = validateInput.ValidateInt("Enter year of the car: ");

                if ((dateTime.Year - vehicles.Year) > 40)
                {   // if vehicle is more than or equals 40 years
                    Console.WriteLine("VEHICLE MUST NOT BE MORE THAN 40");
                }
                else if ((dateTime.Year - vehicles.Year) < 0)
                {   // if year is future year
                    Console.WriteLine("CANT ACCEPT FUTURE YEAR");
                }

            } while ((dateTime.Year - vehicles.Year) > 40 || (dateTime.Year - vehicles.Year) < 0);   // while vehicle age is more than 40 years

            do
            {
                selectionOption = validateInput.ValidateInt("Select the type of car\n1: 4-door sedan\n2: 2-door sports car\n3: SUV\n4: Truck\nSelect: ");

                if (selectionOption == 1)
                {
                    vehicles.Type = "4-door sedan";
                }
                else if (selectionOption == 2)
                {
                    vehicles.Type = "2-door sports car";
                }
                else if (selectionOption == 3)
                {
                    vehicles.Type = "SUV";
                }
                else if (selectionOption == 4)
                {
                    vehicles.Type = "Truck";
                }

            } while (selectionOption >= 5 || selectionOption <= 0);

            do
            {
                selectionOption = validateInput.ValidateInt("Select the FUEL type of car\n1: Diesel\n2: Electric\n3: Petrol\nSelect: ");

                if (selectionOption == 1)
                {
                    vehicles.FuelType = "Diesel";
                }
                else if (selectionOption == 2)
                {
                    vehicles.FuelType = "Electric";
                }
                else if (selectionOption == 3)
                {
                    vehicles.FuelType = "Petrol";
                }

            } while (selectionOption >= 4 || selectionOption <= 0);

            do
            {
                vehicles.PurchasePrice = validateInput.ValidateDecimal("Enter Purchase Price of the car: ");

            } while (vehicles.PurchasePrice <= 0);

            vehicles.PremiumCharged = ratingEngines.PremiumCharge(vehicles, policyHolders);

            currentVehicleList.Add(vehicles);

            return currentVehicleList;
        }
    }
}
