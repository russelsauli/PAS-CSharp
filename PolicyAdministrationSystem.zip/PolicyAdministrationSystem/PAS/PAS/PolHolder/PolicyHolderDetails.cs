﻿using Microsoft.IdentityModel.Tokens;
using PAS.InputValidator;
using POCO.Models;
using System;
using System.Collections.Generic;
using System.Diagnostics.Metrics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PAS.PolHolder
{
    public class PolicyHolderDetails
    {
        public PolicyHolders PolicyHolderDetail(PolicyHolders policyHolders) {

            PASContext pasContext = new PASContext();

            ValidateInput validateInput = new ValidateInput();
           
            DateTime dateTime = DateTime.Now;

            List<PolicyHolders> policyHolderList=pasContext.PolicyHolders.ToList();

            if (policyHolders.FirstName.IsNullOrEmpty())
            {
                policyHolders.FirstName = validateInput.ValidateString("\nEnter First Name: ");
                policyHolders.LastName = validateInput.ValidateString("\nEnter Last Name: ");
                policyHolders.Address = validateInput.ValidateString("\nEnter Address: ");
            }
         
            do
            {
                policyHolders.Birthdate = validateInput.ValidateDate("\nEnter Brithdate:\n ");

                if (policyHolders.Birthdate > dateTime)
                {

                    Console.WriteLine("Cant accept future date ");
                }

                else if ((dateTime.Year - policyHolders.Birthdate.Year) >= 100)
                {
                    Console.WriteLine("Invalid date");
                }

                else if ((dateTime.Year-policyHolders.Birthdate.Year) < 17)
                {
                    Console.WriteLine("Too young to have a policy");
                }

            } while (policyHolders.Birthdate > dateTime || dateTime.Year-(policyHolders.Birthdate.Year ) >= 100 || (dateTime.Year - policyHolders.Birthdate.Year ) < 17);

            do
            {
                policyHolders.DriversLicence = validateInput.ValidateString("\nEnter Driver's License: ");

                if (policyHolderList.Exists(x => x.DriversLicence.Equals(policyHolders.DriversLicence)))
                {
                    Console.WriteLine("Driver's License already exist");
                }

            } while (policyHolderList.Exists(x => x.DriversLicence.Equals(policyHolders.DriversLicence)));
            
            do
            {
                policyHolders.DriversLicenseIssued = validateInput.ValidateDate("\nEnter Driver's License Issued date: ");

                if (policyHolders.DriversLicenseIssued > dateTime)
                {
                    Console.WriteLine("Cant accept future date ");
                }

                else if (( dateTime.Year - policyHolders.DriversLicenseIssued.Year ) >= 100)
                {
                    Console.WriteLine("Invalid date");
                }

                else if ((policyHolders.DriversLicenseIssued.Year -policyHolders.Birthdate.Year ) < 17)
                {
                    Console.WriteLine("Too young to have a license");
                }

            } while (policyHolders.DriversLicenseIssued > dateTime || (policyHolders.DriversLicenseIssued.Year - policyHolders.Birthdate.Year) < 17 || (dateTime.Year - policyHolders.DriversLicenseIssued.Year  ) >= 100);

            return policyHolders;
        }
    }
}
