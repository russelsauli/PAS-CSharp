﻿using Microsoft.EntityFrameworkCore;
using PAS.InputValidator;
using PAS.Print;
using POCO.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PAS.PolHolder
{
    public class SearchPolicy
    {
        public void SearchPolicies() {
        
            PASContext pasContext = new PASContext();
            ValidateInput validateInput = new ValidateInput();
            Printing printing = new Printing(); 

            Policies policies = new Policies(); 
            List<Policies> policieslist = pasContext.Policies.Include(x=>x.PolicyHolder).Include(x => x.PolicyHolder.CustomerAccount).ToList();
            List<Vehicles> vehicleList= new List<Vehicles> ();

            string policyNumber = "";

            Console.WriteLine("");

            policyNumber = validateInput.ValidateString("Enter Policy number: ");


            if (policieslist.Exists(x=>x.PolicyNumber.Equals(policyNumber))) {

                policies= policieslist.Where(x => x.PolicyNumber.Equals(policyNumber)).First();

                vehicleList =pasContext.Vehicles.Include(x=>x.Policy).Where(x => x.Policy.PolicyNumber.Equals(policyNumber)).ToList();

                printing.PrintData(policies);
                printing.PrintData(policies.PolicyHolder);
                printing.PrintData(policies.PolicyHolder.CustomerAccount);

                Console.WriteLine("Vehicle List");

                foreach (Vehicles data in vehicleList) {
                    printing.PrintData(data);
                }
            }
            else {

                Console.WriteLine("Policy number not exist");
            }

        }
    }
}
