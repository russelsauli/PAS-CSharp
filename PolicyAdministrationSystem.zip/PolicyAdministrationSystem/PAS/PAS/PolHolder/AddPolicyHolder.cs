﻿using Microsoft.EntityFrameworkCore;
using PAS.InputValidator;
using POCO.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PAS.PolHolder
{
    public  class AddPolicyHolder
    {
        public PolicyHolders AddPolicyHolders(CustomerAccounts customer) {
        
            PASContext pasContext = new PASContext();  
            
            PolicyHolders policyHolder = new PolicyHolders();

            ValidateInput validateInput = new ValidateInput();

            PolicyHolderDetails policyHolderDetails = new PolicyHolderDetails();

            List<PolicyHolders> policyHolderlist= pasContext.PolicyHolders.Include(x=>x.CustomerAccount).Where(x=>x.CustomerAccount.Equals(customer)).ToList();


            int selectChoice = 0;

            policyHolder.CustomerAccount = customer;

            Console.WriteLine("Add Policy Holder");
            do
            {
                Console.WriteLine("Select Choices");
                Console.WriteLine("1: User Customer Account as Policy holder");
                Console.WriteLine("2: Create new Policy Holder");
                if (policyHolderlist.Count() >= 1)
                {
                    Console.WriteLine("3: Select from Existing Policy holder");
                }

                selectChoice = validateInput.ValidateInt("Select: ");
                if (selectChoice == 1) {

                    if (policyHolderlist.Exists(x => x.FirstName.Equals(policyHolder.CustomerAccount.FirstName) && x.LastName.Equals(policyHolder.CustomerAccount.LastName)))
                    {
                        policyHolder= policyHolderlist.Where(x => x.FirstName.Equals(policyHolder.CustomerAccount.FirstName) && x.LastName.Equals(policyHolder.CustomerAccount.LastName)).First();
                    }
                    else {
                        policyHolder.FirstName=policyHolder.CustomerAccount.FirstName;
                        policyHolder.LastName = policyHolder.CustomerAccount.LastName;
                        policyHolder.Address = policyHolder.CustomerAccount.Address;

                        policyHolderDetails.PolicyHolderDetail(policyHolder);

                    }
                }

                else if (selectChoice == 2)
                {
                    policyHolderDetails.PolicyHolderDetail(policyHolder);
                }

                else if (selectChoice == 3 && policyHolderlist.Count()>=1) {
                    do
                    {
                        Console.WriteLine("Select Policy Holder ID");
                        foreach (PolicyHolders data in policyHolderlist)
                        {

                        }
                        if (!policyHolderlist.Exists(x => x.PolicyHolderId == selectChoice)) {

                            Console.WriteLine("Policy holder Id not exist in this Customer Account");
                        }

                    } while (!policyHolderlist.Exists(x => x.PolicyHolderId == selectChoice));
                   
                }

                else
                {
                    Console.WriteLine("Invalid Input");
                }

            } while (selectChoice > 3 || selectChoice <= 0);
            
            return policyHolder;
        }

    }
}
