﻿
using POCO.Models;

namespace PAS.Print
{
    public class Printing
    {
        public void PrintData(CustomerAccounts customerAccount)
        {

            Console.WriteLine("***********************************************************");
            Console.WriteLine("Customer Account Number  : " + customerAccount.AccountNumber);
            Console.WriteLine("FirstName                : " + customerAccount.FirstName);
            Console.WriteLine("LastName                 : " + customerAccount.LastName);
            Console.WriteLine("Address                  : " + customerAccount.Address);
            Console.WriteLine("***********************************************************");
        }

        public void PrintData(PolicyHolders policyHolder)
        {
            Console.WriteLine("***********************************************************");
            Console.WriteLine("FirstName                : " + policyHolder.FirstName);
            Console.WriteLine("LastName                 : " + policyHolder.LastName);
            Console.WriteLine("Address                  : " + policyHolder.Address);
            Console.WriteLine("Birthdate                : " + policyHolder.Birthdate);
            Console.WriteLine("Driver's License         : " + policyHolder.DriversLicence);
            Console.WriteLine("Driver's License Issued  : " + policyHolder.DriversLicenseIssued);
            Console.WriteLine("***********************************************************");
        }

        public void PrintData(Policies policy)
        {
            Console.WriteLine("***********************************************************");
            Console.WriteLine("Policy Number  : " + policy.PolicyNumber);
            Console.WriteLine("Effective Date : " + policy.EffectiveDate);
            Console.WriteLine("Expiry Date    : " + policy.ExpirationDate);
            Console.WriteLine("Premium Charge : " + policy.PremiumCharge);
            Console.WriteLine("***********************************************************");
        }

        public void PrintData(Vehicles vehicle)
        {
            Console.WriteLine("***********************************************************");
            Console.WriteLine("Plate Number   : " + vehicle.PlateNumber);
            Console.WriteLine("Maker          : " + vehicle.Maker);
            Console.WriteLine("Model          : " + vehicle.Model);
            Console.WriteLine("Color          : " + vehicle.Color);
            Console.WriteLine("Fuel type      : " + vehicle.FuelType);
            Console.WriteLine("Car type       : " + vehicle.Type);
            Console.WriteLine("Year Purchase  : " + vehicle.Year);
            Console.WriteLine("Premium Charge : " + vehicle.PremiumCharged);
            Console.WriteLine("***********************************************************");

        }

        public void PrintData(Claims claims)
        {
            Console.WriteLine("CLAIM#	              :" + claims.ClaimNumber);
            Console.WriteLine("ACCIDENT DATE          :" + claims.AccidentDate);
            Console.WriteLine("ACCIDENT LOCATION      :" + claims.AccidentLocation);
            Console.WriteLine("DESCRIPTION OF ACCIDENT:" + claims.AccidentDescription);
            Console.WriteLine("DESCRIPTION OF DAMAGE  :" + claims.DescriptionOfDamage);
            Console.WriteLine("ESTIMATE COST          :$" + claims.EstimateCost);
        }

        public void PrintChoices() {

            Console.WriteLine("\n1: CREATE A NEW CUSTOMER ACCOUNT");
            Console.WriteLine("2: GET A POLICY QUOTE AND BUY THE POLICY.");
            Console.WriteLine("3: CANCEL A SPECIFIC POLICY  ");
            Console.WriteLine("4: FILE AN ACCIDENT CLAIM AGAINST A POLICY.");
            Console.WriteLine("5: SEARCH FOR A CUSTOMER ACCOUNT ");
            Console.WriteLine("6: SEARCH FOR AND DISPLAY A SPECIFIC POLICY");
            Console.WriteLine("7: SEARCH FOR AND DISPLAY A SPECIFIC CLAIM");
            Console.WriteLine("8: EXIT THE PAS SYSTEM");
            Console.WriteLine("\n_______________________________________________________________\n");
            Console.Write("Select : ");

        }


    }
}
