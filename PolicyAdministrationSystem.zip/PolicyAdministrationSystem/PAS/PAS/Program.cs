﻿
using PAS.Claim;
using PAS.CustomerAccount;
using PAS.PolHolder;
using PAS.Policy;
using PAS.Print;
using POCO.Models;

namespace PAS
{
    public class Programs
    {

        public static void Main(string[] args)
        {
            Printing printing = new Printing();

            string choice = "";
            do
            {
                printing.PrintChoices();

                choice = Console.ReadLine();

                switch (choice) {
                    
                    case "1":
                        CreateCustomer createCustomer  = new CreateCustomer();
                        createCustomer.CreateCustomers();

                        break;

                    case "2":
                        CreatePolicy createPolicy = new CreatePolicy();
                        createPolicy.CreatePolicies();
                        break;

                    case "3":
                        CancelPolicy cancelPolicy = new CancelPolicy();
                        cancelPolicy.CancelPolicies();
                        break;

                    case "4":
                        FileClaim fileClaim = new FileClaim();
                        fileClaim.FileClaims();
                        break;

                    case "5":
                        SearchCustomer searchCustomer = new SearchCustomer();
                        searchCustomer.SearchCustomerAccount();
                        break;

                    case "6":
                        SearchPolicy searchPolicy = new SearchPolicy();
                        searchPolicy.SearchPolicies();  
                        break;

                    case "7":
                        SearchClaims searchClaims=new SearchClaims();
                        searchClaims.SearchClaim();
                        break;

                    case "8":
                        Console.WriteLine("PROGRAM CLOSE");  // stop program
                        break;


                     default:

                        Console.WriteLine("INPUT IS NOT ON SELECTION ");
                        break;
                }

            } while (!choice.Equals("8"));

        }

    }
}
